﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_User_AddRole : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

	protected void AddBtn_Click(object sender,EventArgs e)
	{   ///添加数据
		Role role = new Role();
		role.AddRole(RoleName.Text);
		Response.Write("<script>window.alert('添加数据项成功。')</script>");
	}

	protected void ReturnBtn_Click(object sender,EventArgs e)
	{   ///返回管理页面
		Response.Redirect("~/Admin/User/RoleManage.aspx");
	}
}
