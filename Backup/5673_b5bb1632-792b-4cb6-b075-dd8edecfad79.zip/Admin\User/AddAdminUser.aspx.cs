﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_User_AddAdminUser : System.Web.UI.Page
{
	protected void Page_Load(object sender,EventArgs e)
	{   ///绑定控件的数据
		if(!Page.IsPostBack)
		{
			BindRoleData();
		}
	}

	private void BindRoleData()
	{
		///定义获取数据的类
		Role role = new Role();
		SqlDataReader recr = role.GetRoles();

		///设定控件的数据源
		RoleList.DataSource = recr;

		///设定控件的Text属性和Value属性
		RoleList.DataTextField = "RoleName";
		RoleList.DataValueField = "RoleID";

		///绑定控件的数据
		RoleList.DataBind();

		///关闭数据读取器和数据库的连接
		recr.Close();
	}

	protected void SureBtn_Click(object sender,EventArgs e)
	{
		User user = new User();
		int nUserID = user.AddUser(UserName.Text,RealName.Text,Password.Text,
			Address.Text,Phone.Text,Mobile.Text,Email.Text,
			Int32.Parse(RoleList.SelectedValue),Remark.Text);
		Response.Redirect("~/Desktop/CommitRegister.aspx?UserID=" + nUserID.ToString());
	}
	protected void ReturnBtn_Click(object sender,EventArgs e)
	{	///返回管理页面
		Response.Redirect("~/Admin/User/UserManage.aspx");
	}
}
