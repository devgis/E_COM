﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_User_EditUser : System.Web.UI.Page
{
	private int nUserID = -1;
	protected void Page_Load(object sender,EventArgs e)
	{	///获取参数的值		
		if(Request.Params["UserID"] != null)
		{
			if(Int32.TryParse(Request.Params["UserID"].ToString(),out nUserID) == false)
			{
				return;
			}
		}

		if(!Page.IsPostBack)
		{   ///绑定控件的数据
			if(nUserID > -1)
			{
				BindUserData(nUserID);
			}
		}

		///设置更新按钮的可用性
		SureBtn.Enabled = nUserID <= -1 ? false : true;
	}

	private void BindUserData(int nUserID)
	{	///获取数据
		User user = new User();
		SqlDataReader recr = user.GetSingleUser(nUserID);

		///读取数据
		if(recr.Read())
		{
			///显示数据
			UserName.Text = recr["UserName"].ToString();
			RealName.Text = recr["RealName"].ToString();			
			Email.Text = recr["Email"].ToString();
			Phone.Text = recr["Phone"].ToString();
			Mobile.Text = recr["Mobile"].ToString();
			Remark.Text = recr["Remark"].ToString();
			Address.Text = recr["Address"].ToString();
		}
		recr.Close();          ///关闭数据源
	}

	protected void SureBtn_Click(object sender,EventArgs e)
	{
		User user = new User();
		user.UpdateUser(nUserID,RealName.Text,
			Address.Text,Phone.Text,Mobile.Text,
			Email.Text,Remark.Text);

		Response.Write("<script>window.alert('修改用户信息成功。')</script>");
	}
	protected void ReturnBtn_Click(object sender,EventArgs e)
	{	///返回管理页面
		Response.Redirect("~/Admin/User/UserManage.aspx");
	}
}
