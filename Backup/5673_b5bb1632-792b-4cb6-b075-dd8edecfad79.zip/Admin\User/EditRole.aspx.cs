﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_User_EditRole : System.Web.UI.Page
{
	private int nRoleID = -1;
    protected void Page_Load(object sender, EventArgs e)
    {	///获取参数的值		
		if(Request.Params["RoleID"] != null)
		{
			if(Int32.TryParse(Request.Params["RoleID"].ToString(),out nRoleID) == false)
			{
				return;
			}
		}

		if(!Page.IsPostBack)
		{   ///绑定控件的数据
			if(nRoleID > -1)
			{				
				BindRoleData(nRoleID);
			}
		}

		///设置更新按钮的可用性
		EditBtn.Enabled = nRoleID <= -1 ? false : true;
	}

	private void BindRoleData(int nRoleID)
	{	///获取数据
		Role role = new Role();
		SqlDataReader recr = role.GetSingleRole(nRoleID);

		///读取数据
		if(recr.Read())
		{
			///显示数据
			RoleName.Text = recr["RoleName"].ToString();
		}
		recr.Close();          ///关闭数据源
	}

	protected void EditBtn_Click(object sender,EventArgs e)
	{	///添加数据
		Role role = new Role();
		role.UpdateRole(nRoleID,RoleName.Text);
		Response.Write("<script>window.alert('修改数据项成功。')</script>");
	}
	protected void ReturnBtn_Click(object sender,EventArgs e)
	{   ///返回管理页面
		Response.Redirect("~/Admin/User/RoleManage.aspx");
	}
}
