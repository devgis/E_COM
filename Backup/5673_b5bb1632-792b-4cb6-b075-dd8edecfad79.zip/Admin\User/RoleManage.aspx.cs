﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_User_RoleManage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {   ///绑定控件的数据
		if(!Page.IsPostBack)
		{			
			BindRoleData();
		}

		///添加删除确认对话框
		deleteBtn.Attributes.Add("onclick","return confirm('你确认删除你选择的数据项？');");
	}

	private void BindRoleData()
	{
		///定义获取数据的类
		Role role = new Role();
		SqlDataReader recr = role.GetRoles();

		///设定控件的数据源
		RoleList.DataSource = recr;

		///设定控件的Text属性和Value属性
		RoleList.DataTextField = "RoleName";
		RoleList.DataValueField = "RoleID";

		///绑定控件的数据
		RoleList.DataBind();

		///关闭数据读取器和数据库的连接
		recr.Close();
	}

	protected void AddBtn_Click(object sender,EventArgs e)
	{
		///跳转到添加页面
		Response.Redirect("~/Admin/User/AddRole.aspx");
	}

	protected void editBtn_Click(object sender,ImageClickEventArgs e)
	{
		if(RoleList.SelectedIndex <= -1)
		{   ///提示信息
			Response.Write("<script>window.alert('请选择操作的数据项。')</script>");
			return;
		}

		///跳转到修改页面
		Response.Redirect("~/Admin/User/EditRole.aspx?RoleID=" + RoleList.SelectedValue);
	}

	protected void deleteBtn_Click(object sender,ImageClickEventArgs e)
	{
		if(RoleList.SelectedIndex <= -1)
		{   ///提示信息
			Response.Write("<script>window.alert('请选择操作的数据项。')</script>");
			return;
		}
		///定义类Role
		Role role = new Role();
		///删除数据
		role.DeleteRole(Int32.Parse(RoleList.SelectedValue));

		///显示操作结果信息
		Response.Write("<script>window.alert('删除选择的数据成功。')</script>");

		///重新绑定数据
		BindRoleData();
	}
}
