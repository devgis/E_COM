﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Desktop_Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }	
	
	protected void SureBtn_Click(object sender,EventArgs e)
	{
		User user = new User();
		///存储用户信息		
		UserInfo userInfo = new UserInfo();
		userInfo.UserName = UserName.Text;
		userInfo.RealName = RealName.Text;
		userInfo.Password = Password.Text;
		userInfo.Address  = Address.Text;
		userInfo.Phone    = Phone.Text;
		userInfo.Email    = Email.Text;
		userInfo.Mobile   = Mobile.Text;
		userInfo.Remark   = Remark.Text;	
		Session[Session.SessionID + UserInfo.UserIDString] = userInfo;	
		///跳转到用户信息确认页面
		Response.Redirect("~/Desktop/CommitRegister.aspx");
	}
}
