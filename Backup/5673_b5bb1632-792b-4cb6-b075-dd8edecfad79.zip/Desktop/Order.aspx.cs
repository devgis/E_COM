﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Desktop_Order : System.Web.UI.Page
{
	protected void Page_Load(object sender,EventArgs e)
	{
		if(!Page.IsPostBack)
		{
			///获取购物车的信息			
			ShowCartInfo();
			BindUserData(Int32.Parse(Session["UserID"].ToString()));
		}
	}
	private void BindUserData(int nUserID)
	{	///获取数据
		User user = new User();
		SqlDataReader recr = user.GetSingleUser(nUserID);

		///读取数据
		if(recr.Read())
		{
			///显示数据
			UserName.Text = recr["UserName"].ToString();
			RealName.Text = recr["RealName"].ToString();
			Address.Text = recr["Address"].ToString();
			Email.Text = recr["Email"].ToString();
			Phone.Text = recr["Phone"].ToString();
			Mobile.Text = recr["Mobile"].ToString();
			Remark.Text = recr["Remark"].ToString();
		}
		recr.Close();          ///关闭数据源
	}
	
	private void ShowCartInfo()
	{
		///判定购物车中是否存在数据
		if(Session[Session.SessionID + OrderForm.Cart] == null)
		{
			return;
		}

		///绑定购物车的数据，显示购物车信息
		OrderInfo order = (OrderInfo)Session[Session.SessionID + OrderForm.Cart];
		ProductView.DataSource = order.OrderItemList;
		ProductView.DataBind();
		ProductView.FooterRow.Cells[0].Text = "本次购物的总数量为：" + order.TotalNumber.ToString() + ", 总金额为：" + order.TotalMoney.ToString();
	}	
	protected void ReturnBtn_Click(object sender,EventArgs e)
	{
		Response.Redirect("~/Desktop/Cart.aspx");
	}
	protected void CommitBtn_Click(object sender,EventArgs e)
	{
		///判定购物车中是否存在数据
		if(Session[Session.SessionID + OrderForm.Cart] == null)
		{
			return;
		}
		///获取订单信息
		OrderInfo order = (OrderInfo)Session[Session.SessionID + OrderForm.Cart];
		OrderForm orderform = new OrderForm();
		///添加订单信息到数据库中
		int nOrderFormID = orderform.AddOrderForm(Int32.Parse(Session["UserID"].ToString()),
			order.TotalNumber,
			order.TotalMoney);
		if(nOrderFormID > -1)
		{
			///添加订单中的每一个子项
			OrderItem orderItem = new OrderItem();
			foreach(OrderItemInfo item in order.OrderItemList)
			{
				orderItem.AddOrderItem(item.ProductID,item.Number,nOrderFormID);
			}
		}

		///显示提示信息
		Response.Write("<script>alert(\"提交订单成功！！！\")</script>");		
	}
}
