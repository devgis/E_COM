﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Desktop_Comment : System.Web.UI.Page
{
	private int nProductID = -1;
	protected void Page_Load(object sender,EventArgs e)
	{
		///获取参数的值		
		if(Request.Params["ProductID"] != null)
		{
			if(Int32.TryParse(Request.Params["ProductID"].ToString(),out nProductID) == false)
			{
				return;
			}
		}
		if(!Page.IsPostBack)
		{   ///绑定控件的数据
			if(nProductID > -1)
			{
				BindCommentData(nProductID);
			}
		}
	}
	private void BindCommentData(int nProductID)
	{
		///定义获取数据的类
		Comment comment = new Comment();
		SqlDataReader dr = comment.GetCommentByProduct(nProductID);

		///设定控件的数据源
		CommentView.DataSource = dr;
		///绑定控件的数据
		CommentView.DataBind();

		///关闭数据读取器和数据库的连接
		dr.Close();
	}
	protected void SureBtn_Click(object sender,EventArgs e)
	{
		if(Session["UserID"] == null)
		{
			Response.Write("<script>window.alert('用户未登录，请先登录。')</script>");
			return;
		}
		Comment comment = new Comment();
		comment.AddComment(Desn.Text,Body.Text,nProductID,Int32.Parse(Session["UserID"].ToString()));
		///显示操作结果信息
		Response.Write("<script>window.alert('添加数据项成功。')</script>");

		///重新绑定数据
		BindCommentData(nProductID);
	}
	protected void ReturnBtn_Click(object sender,EventArgs e)
	{
		Response.Write("<script>window.close();</script>");
	}
}
