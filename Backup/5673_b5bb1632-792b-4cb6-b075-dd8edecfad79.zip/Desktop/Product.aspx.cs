﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Desktop_Product : System.Web.UI.Page
{
    private int nCategoryID = -1;
    protected void Page_Load(object sender, EventArgs e)
    {	///获取参数的值		
        if (Request.Params["CategoryID"] != null)
        {
            if (Int32.TryParse(Request.Params["CategoryID"].ToString(), out nCategoryID) == false)
            {
                return;
            }
        }

        ///绑定控件的数据
        if (!Page.IsPostBack)
        {
            BindCategoryData();
            if (nCategoryID > 0)
            {
                BindProductData(nCategoryID);

            }
            else
            {
                BindProductData(1);

            }
        }


    }

    private void BindCategoryData()
    {	///定义获取数据的类
        Category category = new Category();
        SqlDataReader drc = category.GetSubCategorys(1);
        ///设定控件的数据源
        ProductList.DataSource = drc;
        ///绑定控件的数据
        ProductList.DataBind();
        ///关闭数据读取器和数据库的连接
        drc.Close();
    }
    private void BindProductData(int nCategoryID)
    {
        ///定义获取数据的类
        Product product = new Product();
        SqlDataReader dr = product.GetProductByCategory(nCategoryID);

        ///设定控件的数据源
        ProductView.DataSource = dr;
        ///绑定控件的数据
        ProductView.DataBind();

        ///关闭数据读取器和数据库的连接
        dr.Close();
    }
    protected void ProductView_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        OrderItemInfo item = null;
        OrderInfo order = null;

        ///添加到购物车中，购物车的数据使用Session保存
        if (Session[Session.SessionID + OrderForm.Cart] == null)
        {
            ///当购物车没有任何信息时
            item = GetOrderItemInformation(e);
            if (item == null)
            {
                ///显示错误信息					
                Response.Write("<script>window.alert('数据错误')</script>");
                return;
            }

            ///创建订单信息               
            order = new OrderInfo();
            order.OrderItemList.Add(item);
            order.TotalMoney = item.Price;
            order.TotalNumber = item.Number;

            ///添加订单信息到Session中
            Session[Session.SessionID + OrderForm.Cart] = order;
        }
        else
        {
            ///当购物车中已经存在商品信息时，从Session中获取以前的商品信息
            order = (OrderInfo)Session[Session.SessionID + OrderForm.Cart];
            item = GetOrderItemInformation(e);
            if (item == null)
            {
                ///显示错误信息
                Response.Write("<script>window.alert('数据错误')</script>");
                return;
            }

            ///判断是否已经添加该类型的商品
            int i = 0;
            for (i = 0; i < order.OrderItemList.Count; i++)
            {
                ///如果添加了，则数量加一
                if (item.ProductID == ((OrderItemInfo)order.OrderItemList[i]).ProductID)
                {
                    ((OrderItemInfo)order.OrderItemList[i]).Number++;
                    ((OrderItemInfo)order.OrderItemList[i]).ItemTotalMoney += item.ItemTotalMoney;
                    break;
                }
            }
            ///否则添加新的商品
            if (i == order.OrderItemList.Count)
            {
                order.OrderItemList.Add(item);
            }
            ///更新订单信息
            order.TotalNumber++;
            order.TotalMoney += item.Price;
            Session[Session.SessionID + OrderForm.Cart] = order;
            
        }
        Response.Write("<script>window.alert('恭喜您，添加该商品到购物车成功！')</script>");
        
    }

    private OrderItemInfo GetOrderItemInformation(GridViewCommandEventArgs e)
    {
        ///当购物车没有任何信息时
        OrderItemInfo item = new OrderItemInfo();
        item.Date = DateTime.Now;
        item.Number = 1;

        ///获取商品价格
        Label priceL = (Label)ProductView.Rows[
            Int32.Parse(e.CommandArgument.ToString())].FindControl("Price");
        if (priceL == null)
        {
            ///显示错误信息
            Response.Write("<script>window.alert('数据错误')</script>");
            return null;
        }
        item.Price = item.ItemTotalMoney = decimal.Parse(priceL.Text.Trim());
        ///获取商品ID
        item.ProductID = Int32.Parse(ProductView.DataKeys[
            Int32.Parse(e.CommandArgument.ToString())].Value.ToString());
        ///获取商品名称
        item.Name = e.CommandName;
        return (item);
    }
    protected void ProductView_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Button buyBtn = (Button)e.Row.FindControl("BuyBtn");
            if (buyBtn != null)
            {
                buyBtn.CommandArgument = e.Row.RowIndex.ToString();
            }
        }
    }
    protected void BuyBtn_Click(object sender, EventArgs e)
    {

    }
}
