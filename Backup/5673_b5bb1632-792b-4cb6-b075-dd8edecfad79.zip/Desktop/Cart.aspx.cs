﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Desktop_Cart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		if(!Page.IsPostBack)
		{
			///获取购物车的信息			
			ShowCartInfo();
		}
	}
	private void ShowCartInfo()
	{
		///判定购物车中是否存在数据
		if(Session[Session.SessionID + OrderForm.Cart] == null)
		{
			return;
		}

		///绑定购物车的数据，显示购物车信息
		OrderInfo order = (OrderInfo)Session[Session.SessionID + OrderForm.Cart];
		ProductView.DataSource = order.OrderItemList;
		ProductView.DataBind();		
	}
	protected void ContinueBtn_Click(object sender,EventArgs e)
	{
		Response.Redirect("~/Desktop/Product.aspx");
	}
	protected void CommitBtn_Click(object sender,EventArgs e)
	{
		Response.Redirect("~/Desktop/Order.aspx");
	}
	protected void ProductView_RowCommand(object sender,GridViewCommandEventArgs e)
	{
		///判定购物车中是否存在数据
		if(Session[Session.SessionID + OrderForm.Cart] == null)
		{			
			return;
		}
		///删除购物车中的商品
		if(e.CommandName.ToLower() == "delete")
		{
			///获取购物车的信息
			OrderInfo order = (OrderInfo)Session[Session.SessionID + OrderForm.Cart];
			order.OrderItemList.RemoveAt(Int32.Parse(e.CommandArgument.ToString()));

			///重新绑定购物车的数据
			ShowCartInfo();
		}
	}
	protected void ProductView_RowDeleting(object sender,GridViewDeleteEventArgs e)
	{
		///
	}
	protected void ProductView_RowDataBound(object sender,GridViewRowEventArgs e)
	{
		///找到删除按钮
		ImageButton deleteBtn = (ImageButton)e.Row.FindControl("DeleteBtn");
		if(deleteBtn != null)
		{   ///添加删除确认对话框
			deleteBtn.Attributes.Add("onclick","return confirm('你确定要删除所选择的数据项吗？');");
		}
	}
	protected void ProductView_RowCreated(object sender,GridViewRowEventArgs e)
	{
		///添加行的索引到CommandArgument参数中
		if(e.Row.RowType == DataControlRowType.DataRow)
		{
			///找到删除按钮
			ImageButton deleteBtn = (ImageButton)e.Row.FindControl("DeleteBtn");
			if(deleteBtn != null)
			{   ///添加参数的值
				deleteBtn.CommandArgument = e.Row.RowIndex.ToString();
			}
		}			
	}
}
