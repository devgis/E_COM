﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Desktop_leaveword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		if(Session["UserID"] == null)
		{
			SureBtn.Enabled = false;
		}
	}
	protected void SureBtn_Click(object sender,EventArgs e)
	{   ///定义类
		Leaveword word = new Leaveword();
		///添加数据
		word.AddLeaveword(Desn.Text,Body.Text,Int32.Parse(Session["UserID"].ToString()));
		///显示操作结果信息
		Response.Write("<script>window.alert('添加数据项成功。')</script>");
	}	
}
