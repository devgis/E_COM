﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Desktop_ViewNotify : System.Web.UI.Page
{
	protected void Page_Load(object sender,EventArgs e)
	{
		if(!Page.IsPostBack)
		{
			BindNotifyData();
		}
	}
	private void BindNotifyData()
	{
		Notify notify = new Notify();
		SqlDataReader recc = notify.GetNotify();
		if(recc.Read())
		{
			Desn.Text = recc["Desn"].ToString();
			Body.Text = recc["Body"].ToString();
		}
		recc.Close();
	}
	protected void SureBtn_Click(object sender,EventArgs e)
	{
		Response.Write("<script>window.close();</script>");
	}
}
