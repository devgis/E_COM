﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Desktop_Search : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		if(!Page.IsPostBack)
		{
			if(Request.QueryString["Keyword"] != null)
			{
				Keyword.Text = Server.HtmlDecode(Request.QueryString["Keyword"].ToString());
			}
		}
    }
	protected void CommitBtn_Click(object sender,EventArgs e)
	{
		///获取搜索结果
		Product product = new Product();
		DataSet ds = new DataSet("Product");
		ds.Tables.Add(product.SearchProduct(Keyword.Text));

		///绑定控件的数据，显示搜索结果
		ProductView.DataSource = ds;
		ProductView.DataBind();

		///显示提示信息
		ProductView.Visible = ProductView.Rows.Count <= 0 ? false : true;
	}
}
