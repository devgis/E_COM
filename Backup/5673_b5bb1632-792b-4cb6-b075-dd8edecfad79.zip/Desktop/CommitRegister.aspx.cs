﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Desktop_CommitRegister : System.Web.UI.Page
{
	protected string Remark = "";
    protected void Page_Load(object sender, EventArgs e)
    {
		if(!Page.IsPostBack)
		{   ///显示用户信息
			ShowUserInfo();
		}
    }
	private void ShowUserInfo()
	{
		if(Session[Session.SessionID + UserInfo.UserIDString] == null)
		{
			return;
		}
		///获取用户注册信息
		UserInfo userInfo = (UserInfo)Session[Session.SessionID + UserInfo.UserIDString];
		UserName.Text = userInfo.UserName;
		RealName.Text = userInfo.RealName;
		Password.Text = userInfo.Password;
		Phone.Text = userInfo.Phone;
		Mobile.Text = userInfo.Mobile;
		Email.Text = userInfo.Email;
		Address.Text = userInfo.Address;
		Remark = userInfo.Remark;
	}

	protected void ReturnBtn_Click(object sender,EventArgs e)
	{
		Response.Redirect("~/Desktop/Register.aspx");
	}
	protected void SureBtn_Click(object sender,EventArgs e)
	{
		if(Session[Session.SessionID + UserInfo.UserIDString] == null)
		{
			return;
		}
		///获取用户注册信息
		UserInfo userInfo = (UserInfo)Session[Session.SessionID + UserInfo.UserIDString];

		User user = new User();
		///添加用户信息
		if(user.AddUser(userInfo.UserName,
			userInfo.RealName,userInfo.Password,userInfo.Address,
			userInfo.Phone,userInfo.Mobile,userInfo.Email,3,userInfo.Remark) > -1)
		{
			///显示操作结果信息
			Response.Write("<script>window.alert('新用户注册成功。')</script>");
		}
		else
		{
			Response.Write("<script>window.alert('新用户注册失败，请检查注册信息。')</script>");
		}
	}
}
