﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_Information_leavewordManage : System.Web.UI.Page
{
	protected void Page_Load(object sender,EventArgs e)
	{
		if(!Page.IsPostBack)
		{   ///绑定控件的数据
			BindLeavewordData();
		}
	}
	private void BindLeavewordData()
	{
		///定义获取数据的类
		Leaveword word = new Leaveword();
		SqlDataReader dr = word.GetLeavewords();

		///设定控件的数据源
		LeavewordView.DataSource = dr;
		///绑定控件的数据
		LeavewordView.DataBind();

		///关闭数据读取器和数据库的连接
		dr.Close();
	}

	protected void LeavewordView_RowCommand(object sender,GridViewCommandEventArgs e)
	{
		if(e.CommandName == "delete")
		{
			///删除数据
			Leaveword word = new Leaveword();
			word.DeleteLeaveword(Int32.Parse(e.CommandArgument.ToString()));

			///重新绑定控件的数据				
			BindLeavewordData();
			Response.Write("<script>alert('" + "删除数据成功，请妥善保管好你的数据！" + "');</script>");
		}
	}
	protected void LeavewordView_RowDeleting(object sender,GridViewDeleteEventArgs e)
	{
		///
	}
	protected void LeavewordView_RowDataBound(object sender,GridViewRowEventArgs e)
	{
		///找到删除按钮
		ImageButton deleteBtn = (ImageButton)e.Row.FindControl("DeleteBtn");
		if(deleteBtn != null)
		{   ///添加删除确认对话框
			deleteBtn.Attributes.Add("onclick","return confirm('你确定要删除所选择的数据项吗？');");
		}
	}	
}
