﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_Information_NewsInfo : System.Web.UI.Page
{
	private int nNewsID = -1;
	protected void Page_Load(object sender,EventArgs e)
	{	///获取参数的值		
		if(Request.Params["NewsID"] != null)
		{
			if(Int32.TryParse(Request.Params["NewsID"].ToString(),out nNewsID) == false)
			{
				return;
			}
		}
		if(!Page.IsPostBack)
		{
			BindNewsData(nNewsID);
		}
	}
	private void BindNewsData(int nNewsID)
	{
		News news = new News();
		SqlDataReader recc = news.GetSingleNews(nNewsID);
		if(recc.Read())
		{
			Desn.Text = recc["Desn"].ToString();
			Body.Text = recc["Body"].ToString();
		}
		recc.Close();
	}
	protected void SureBtn_Click(object sender,EventArgs e)
	{
		Response.Write("<script>window.close();</script>");
	}
}
