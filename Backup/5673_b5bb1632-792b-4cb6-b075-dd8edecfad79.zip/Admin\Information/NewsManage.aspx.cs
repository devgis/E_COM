﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_Information_NewsManage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		if(!Page.IsPostBack)
		{   ///绑定控件的数据
			BindNewsData();
		}		
    }
	private void BindNewsData()
	{
		///定义获取数据的类
		News news = new News();
		SqlDataReader dr = news.GetNewss();

		///设定控件的数据源
		NewsView.DataSource = dr;
		///绑定控件的数据
		NewsView.DataBind();

		///关闭数据读取器和数据库的连接
		dr.Close();
	}
	
	protected void NewsView_RowCommand(object sender,GridViewCommandEventArgs e)
	{
		if(e.CommandName == "delete")
		{
			///删除数据
			News news = new News();
			news.DeleteNews(Int32.Parse(e.CommandArgument.ToString()));

			///重新绑定控件的数据				
			BindNewsData();
			Response.Write("<script>alert('" + "删除数据成功，请妥善保管好你的数据！" + "');</script>");
		}
	}
	protected void NewsView_RowDeleting(object sender,GridViewDeleteEventArgs e)
	{
		///
	}
	protected void NewsView_RowDataBound(object sender,GridViewRowEventArgs e)
	{
		///找到删除按钮
		ImageButton deleteBtn = (ImageButton)e.Row.FindControl("DeleteBtn");
		if(deleteBtn != null)
		{   ///添加删除确认对话框
			deleteBtn.Attributes.Add("onclick","return confirm('你确定要删除所选择的数据项吗？');");
		}
	}
	protected void SureBtn_Click(object sender,EventArgs e)
	{
		Response.Redirect("~/Admin/Information/AddNews.aspx");
	}
}
