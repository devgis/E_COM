﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_Information_Notice : System.Web.UI.Page
{
	protected void Page_Load(object sender,EventArgs e)
	{	
		if(!Page.IsPostBack)
		{
			BindNotifyData();
		}
	}
	private void BindNotifyData()
	{
		Notify notify = new Notify();
		SqlDataReader recc = notify.GetNotify();
		if(recc.Read())
		{
			Desn.Text = recc["Desn"].ToString();
			Body.Text = recc["Body"].ToString();
		}
		recc.Close();
	}
	protected void SureBtn_Click(object sender,EventArgs e)
	{
		///定义类
		Notify notify = new Notify();
		///修改数据
		notify.UpdateNotify(Desn.Text,Body.Text);
		///显示操作结果信息
		Response.Write("<script>window.alert('修改数据项成功。')</script>");
	}	
}
