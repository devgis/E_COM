﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_Product_AddCategory : System.Web.UI.Page
{
	private int nCategoryID = -1;
	protected void Page_Load(object sender,EventArgs e)
	{	///获取参数的值		
		if(Request.Params["CategoryID"] != null)
		{
			if(Int32.TryParse(Request.Params["CategoryID"].ToString(),out nCategoryID) == false)
			{
				return;
			}
		}
	}
	protected void SureBtn_Click(object sender,EventArgs e)
	{
		///定义类
		Category category = new Category();
		///添加数据
		category.AddCategory(Desn.Text.Trim(),nCategoryID,Remark.Text);
		///显示操作结果信息
		Response.Write("<script>window.alert('添加数据项成功。')</script>");
	}
	protected void ReturnBtn_Click(object sender,EventArgs e)
	{
		///返回管理页面
		Response.Redirect("~/Admin/Product/Category.aspx");
	}
}
