﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_Product_ProductManage : System.Web.UI.Page
{
	private int nCategoryID = -1;
	protected void Page_Load(object sender,EventArgs e)
	{	///获取参数的值		
		if(Request.Params["CategoryID"] != null)
		{
			if(Int32.TryParse(Request.Params["CategoryID"].ToString(),out nCategoryID) == false)
			{
				return;
			}
		}
		///绑定控件的数据
		if(!Page.IsPostBack)
		{
			BindProductData(nCategoryID);
		}
	}
	private void BindProductData(int nCategoryID)
	{
		///定义获取数据的类
		Product product = new Product();
		SqlDataReader dr = product.GetProductByCategory(nCategoryID);

		///设定控件的数据源
		ProductView.DataSource = dr;
		///绑定控件的数据
		ProductView.DataBind();

		///关闭数据读取器和数据库的连接
		dr.Close();
	}

	protected void ProductView_RowCommand(object sender,GridViewCommandEventArgs e)
	{
		if(e.CommandName == "delete")
		{
			///删除数据
			Product product = new Product();
			product.DeleteProduct(Int32.Parse(e.CommandArgument.ToString()));

			///重新绑定控件的数据				
			BindProductData(nCategoryID);
			Response.Write("<script>alert('" + "删除数据成功，请妥善保管好你的数据！" + "');</script>");
		}
	}
	protected void ProductView_RowDeleting(object sender,GridViewDeleteEventArgs e)
	{
		///
	}
	protected void ProductView_RowDataBound(object sender,GridViewRowEventArgs e)
	{
		///找到删除按钮
		ImageButton deleteBtn = (ImageButton)e.Row.FindControl("DeleteBtn");
		if(deleteBtn != null)
		{   ///添加删除确认对话框
			deleteBtn.Attributes.Add("onclick","return confirm('你确定要删除所选择的数据项吗？');");
		}
	}
	protected void SureBtn_Click(object sender,EventArgs e)
	{
		///跳转到添加页面
		Response.Redirect("~/Admin/Product/AddProduct.aspx?CategoryID=" + nCategoryID.ToString());
	}
}
