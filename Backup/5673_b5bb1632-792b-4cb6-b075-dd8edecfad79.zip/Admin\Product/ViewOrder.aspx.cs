﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_Product_ViewOrder : System.Web.UI.Page
{
	protected int nOrderID = -1;
	protected void Page_Load(object sender,EventArgs e)
	{
		Session["UserID"] = 1;
		///获取参数的值		
		if(Request.Params["OrderID"] != null)
		{
			if(Int32.TryParse(Request.Params["OrderID"].ToString(),out nOrderID) == false)
			{
				return;
			}
		}
		///绑定控件的数据
		if(!Page.IsPostBack)
		{
			BindItemData(nOrderID);
			BindUserData(Int32.Parse(Session["UserID"].ToString()));
		}
	}
	private void BindItemData(int nOrderID)
	{
		///定义获取数据的类
		OrderItem item = new OrderItem();
		SqlDataReader dr = item.GetOrderItemByForm(nOrderID);

		///设定控件的数据源
		ProductView.DataSource = dr;
		///绑定控件的数据
		ProductView.DataBind();

		///关闭数据读取器和数据库的连接
		dr.Close();
	}

	private void BindUserData(int nUserID)
	{	///获取数据
		User user = new User();
		SqlDataReader recr = user.GetSingleUser(nUserID);

		///读取数据
		if(recr.Read())
		{
			///显示数据
			UserName.Text = recr["UserName"].ToString();
			RealName.Text = recr["RealName"].ToString();
			Address.Text = recr["Address"].ToString();
			Email.Text = recr["Email"].ToString();
			Phone.Text = recr["Phone"].ToString();
			Mobile.Text = recr["Mobile"].ToString();
			Remark.Text = recr["Remark"].ToString();			
		}
		recr.Close();          ///关闭数据源
	}

	protected void ProductView_RowCommand(object sender,GridViewCommandEventArgs e)
	{
		if(e.CommandName == "delete")
		{
			///删除数据
			OrderItem item = new OrderItem();
			item.DeleteOrderItem(Int32.Parse(e.CommandArgument.ToString()));

			///重新绑定控件的数据				
			BindItemData(nOrderID);
			Response.Write("<script>alert('" + "删除数据成功，请妥善保管好你的数据！" + "');</script>");
		}
	}
	protected void ProductView_RowDeleting(object sender,GridViewDeleteEventArgs e)
	{
		///
	}
	protected void ProductView_RowDataBound(object sender,GridViewRowEventArgs e)
	{
		///找到删除按钮
		ImageButton deleteBtn = (ImageButton)e.Row.FindControl("DeleteBtn");
		if(deleteBtn != null)
		{   ///添加删除确认对话框
			deleteBtn.Attributes.Add("onclick","return confirm('你确定要删除所选择的数据项吗？');");
		}
	}	
	protected void ReturnBtn_Click(object sender,EventArgs e)
	{
		///返回管理页面
		Response.Redirect("~/Admin/Product/OrderManage.aspx");
	}
}
