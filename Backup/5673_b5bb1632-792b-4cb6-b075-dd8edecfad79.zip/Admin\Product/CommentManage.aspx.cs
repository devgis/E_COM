﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_Product_CommentManage : System.Web.UI.Page
{
	private int nProductID = -1;
	private int nCategoryID = -1;
	protected void Page_Load(object sender,EventArgs e)
	{
		///获取参数的值		
		if(Request.Params["CategoryID"] != null)
		{
			if(Int32.TryParse(Request.Params["CategoryID"].ToString(),out nCategoryID) == false)
			{
				return;
			}
		}	///获取参数的值		
		if(Request.Params["ProductID"] != null)
		{
			if(Int32.TryParse(Request.Params["ProductID"].ToString(),out nProductID) == false)
			{
				return;
			}
		}
		if(!Page.IsPostBack)
		{   ///绑定控件的数据
			if(nProductID > -1)
			{
				BindCommentData(nProductID);
			}
		}		
	}
	private void BindCommentData(int nProductID)
	{
		///定义获取数据的类
		Comment comment = new Comment();
		SqlDataReader dr = comment.GetCommentByProduct(nProductID);

		///设定控件的数据源
		CommentView.DataSource = dr;
		///绑定控件的数据
		CommentView.DataBind();

		///关闭数据读取器和数据库的连接
		dr.Close();
	}

	protected void ReturnBtn_Click(object sender,EventArgs e)
	{	///返回管理页面
		Response.Redirect("~/Admin/Product/ProductManage.aspx?CategoryID=" + nCategoryID.ToString());
	}
	protected void CommentView_RowCommand(object sender,GridViewCommandEventArgs e)
	{
		if(e.CommandName == "delete")
		{
			///删除数据
			Comment comment = new Comment();
			comment.DeleteComment(Int32.Parse(e.CommandArgument.ToString()));

			///重新绑定控件的数据				
			BindCommentData(nProductID);
			Response.Write("<script>alert('" + "删除数据成功，请妥善保管好你的数据！" + "');</script>");
		}
	}
	protected void CommentView_RowDeleting(object sender,GridViewDeleteEventArgs e)
	{
		///
	}
	protected void CommentView_RowDataBound(object sender,GridViewRowEventArgs e)
	{
		///找到删除按钮
		ImageButton deleteBtn = (ImageButton)e.Row.FindControl("DeleteBtn");
		if(deleteBtn != null)
		{   ///添加删除确认对话框
			deleteBtn.Attributes.Add("onclick","return confirm('你确定要删除所选择的数据项吗？');");
		}
	}
}
