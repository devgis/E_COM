﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_Product_Category : System.Web.UI.Page
{
	protected void Page_Load(object sender,EventArgs e)
	{
		if(!Page.IsPostBack)
		{
			BindCategoryData();			
		}
		///设置按钮的可用性
		AddBtn.Enabled = UpBtn.Enabled = DownBtn.Enabled = EditBtn.Enabled = DeleteBtn.Enabled
			= CategoryView.SelectedNode == null ? false : true;

		///添加删除确认对话框
		DeleteBtn.Attributes.Add("onclick","return confirm('你确定要删除所选择的数据项吗？');");
	}

	private void BindCategoryData()
	{
		Category category = new Category();
		category.BindCategoryTreeView(CategoryView,true,"-1");
	}

	protected void MoveBtn_Click(object sender,EventArgs e)
	{
		string sCommandName = ((Button)sender).CommandName;

		///验证是否选择修改的数据
		if(CategoryView.SelectedNode == null)
		{
			Response.Write("<script>window.alert('请选择数据项。')</script>");
			return;
		}

		///定义类
		Category category = new Category();
		///修改数据
		category.UpdateCategoryOrder(Int32.Parse(CategoryView.SelectedNode.Value),sCommandName);
		BindCategoryData();

		///显示操作结果信息
		Response.Write("<script>window.alert('修改数据项成功。')</script>");
	}

	protected void DeleteBtn_Click(object sender,EventArgs e)
	{
		///验证是否选择修改的数据
		if(CategoryView.SelectedNode == null)
		{
			Response.Write("<script>window.alert('请选择数据项。')</script>");
			return;
		}

		///验证选择结点的孩子结点是否为空
		if(CategoryView.SelectedNode.ChildNodes.Count > 0)
		{
			Response.Write("<script>window.alert('将要删除的节点还包含孩子节点，该节点不能删除')</script>");
			return;
		}

		///定义类
		Category category = new Category();
		///删除数据
		category.DeleteCategory(Int32.Parse(CategoryView.SelectedNode.Value));
		BindCategoryData();

		///显示操作结果信息
		Response.Write("<script>window.alert('删除数据项成功。')</script>");
	}

	protected void EditBtn_Click(object sender,EventArgs e)
	{
		///验证是否选择修改的数据
		if(CategoryView.SelectedNode == null)
		{
			Response.Write("<script>window.alert('请选择数据项。')</script>");
			return;
		}
		Response.Redirect("~/Admin/Product/EditCategory.aspx?CategoryID=" + CategoryView.SelectedNode.Value);
	}
	protected void AddBtn_Click(object sender,EventArgs e)
	{
		///验证是否选择修改的数据
		if(CategoryView.SelectedNode == null)
		{
			Response.Write("<script>window.alert('请选择数据项。')</script>");
			return;
		}
		Response.Redirect("~/Admin/Product/AddCategory.aspx?CategoryID=" + CategoryView.SelectedNode.Value);
	}
}
