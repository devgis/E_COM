﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_Product_CommentInfo : System.Web.UI.Page
{
	protected string Desn = "";
	protected string Body = "";
	protected string Date = "";
	protected string UserName = "";
	
	private int nCommentID = -1;
	protected void Page_Load(object sender,EventArgs e)
	{	///获取参数的值		
		if(Request.Params["CommentID"] != null)
		{
			if(Int32.TryParse(Request.Params["CommentID"].ToString(),out nCommentID) == false)
			{
				return;
			}
		}
		if(!Page.IsPostBack)
		{   ///绑定控件的数据
			if(nCommentID > -1)
			{
				BindCommentData(nCommentID);
			}
		}
	}

	private void BindCommentData(int nCommentID)
	{	///获取数据
		Comment comment = new Comment();
		SqlDataReader dr = comment.GetSingleComment(nCommentID);

		///读取数据
		if(dr.Read())
		{
			///显示数据
			Desn = dr["Desn"].ToString();
			Body = dr["Body"].ToString();
			Date = dr["Date"].ToString();
			UserName = dr["UserName"].ToString();
		}
		dr.Close();          ///关闭数据源
	}
	protected void ReturnBtn_Click(object sender,EventArgs e)
	{
		Response.Write("<script>window.close();</script>");
	}
}
