﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_Product_ProductInfo : System.Web.UI.Page
{
	private int nProductID = -1;
	protected void Page_Load(object sender,EventArgs e)
	{	///获取参数的值		
		if(Request.Params["ProductID"] != null)
		{
			if(Int32.TryParse(Request.Params["ProductID"].ToString(),out nProductID) == false)
			{
				return;
			}
		}
		if(!Page.IsPostBack)
		{   ///绑定控件的数据
			if(nProductID > -1)
			{
				BindProductData(nProductID);
			}
		}		
	}

	private void BindProductData(int nProductID)
	{	///获取数据
		Product product = new Product();
		SqlDataReader dr = product.GetSingleProduct(nProductID);

		///读取数据
		if(dr.Read())
		{
			///显示数据
			Name.Text = dr["Name"].ToString();
			Desn.Text = dr["Desn"].ToString();
			Sell.Text = dr["Sell"].ToString();
			CreateDate.Text = dr["CreateDate"].ToString();
			SellInDate.Text = dr["SellInDate"].ToString();
			Unit.Text = dr["Unit"].ToString();
			Quantity.Text = dr["Quantity"].ToString();
			InPrice.Text = dr["InPrice"].ToString();
			OutPrice.Text = dr["OutPrice"].ToString();
			Upper.Text = dr["Upper"].ToString();
			Lower.Text = dr["Lower"].ToString();
			Remark.Text = dr["Remark"].ToString();
		}
		dr.Close();          ///关闭数据源
	}

	protected void SureBtn_Click(object sender,EventArgs e)
	{
		Response.Write("<script>window.close();</script>");
	}
}
