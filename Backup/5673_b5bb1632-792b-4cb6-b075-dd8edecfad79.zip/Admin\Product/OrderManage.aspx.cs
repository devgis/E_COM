﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_Product_OrderManage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		Session["UserID"] = 1;
		///绑定控件的数据
		if(!Page.IsPostBack)
		{
			BindOrderData();
		}
	}
	private void BindOrderData()
	{
		///定义获取数据的类
		OrderForm order = new OrderForm();
		SqlDataReader dr = order.GetOrderFormByUser(Int32.Parse(Session["UserID"].ToString()));

		///设定控件的数据源
		OrderView.DataSource = dr;
		///绑定控件的数据
		OrderView.DataBind();

		///关闭数据读取器和数据库的连接
		dr.Close();
	}

	protected void OrderView_RowCommand(object sender,GridViewCommandEventArgs e)
	{
		if(e.CommandName == "commit")
		{
			///提交订单
			OrderForm order = new OrderForm();
			order.CommitOrderForm(Int32.Parse(e.CommandArgument.ToString()));

			///重新绑定控件的数据				
			BindOrderData();
			Response.Write("<script>alert('" + "提交订单成功，请妥善保管好你的数据！" + "');</script>");
		}
	}	
}
