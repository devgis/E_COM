﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_Product_AddProduct : System.Web.UI.Page
{
	private int nCategoryID = -1;
	protected void Page_Load(object sender,EventArgs e)
	{	///获取参数的值		
		if(Request.Params["CategoryID"] != null)
		{
			if(Int32.TryParse(Request.Params["CategoryID"].ToString(),out nCategoryID) == false)
			{
				return;
			}
		}
    }
	protected void SureBtn_Click(object sender,EventArgs e)
	{
		int nPictureID = 1;
		///定义
		Product product = new Product();
		///添加数据
		product.AddProduct(Name.Text,nCategoryID,Desn.Text,Sell.Text,
			DateTime.Parse(CreateDate.Text),DateTime.Parse(SellInDate.Text),
			Unit.Text,Int32.Parse(Quantity.Text),Int32.Parse(Upper.Text),
			Int32.Parse(Lower.Text),Decimal.Parse(InPrice.Text),
			Decimal.Parse(OutPrice.Text),nPictureID,Remark.Text);
		///显示操作结果信息
		Response.Write("<script>window.alert('添加数据项成功。')</script>");
	}
	protected void ReturnBtn_Click(object sender,EventArgs e)
	{	///返回管理页面
		Response.Redirect("~/Admin/Product/ProductManage.aspx?CategoryID=" + nCategoryID.ToString());
	}
}
