﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


public class ProductInfo
{
	public int ProductID;
	public int CategoryID;
	public string Name;
	public string Desn;
	public string Sell;
	public DateTime CreateDate;
	public DateTime SellInDate;
	public string Unit;
	public int Quantity;
	public int Upper;
	public int Lower;
	public Decimal InPrice;
	public Decimal OutPrice;
	public int PictureID;
	public string Remark;
}
/// <summary>
/// Product 的摘要说明
/// </summary>
public class Product
{
	public SqlDataReader GetProducts()
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///定义保存从数据库获取的结果的DataReader
		SqlDataReader dr = null;

		try
		{
			///执行存储过程
			sqlHelper.RunProc("Pr_GetProducts",out dr);
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常			
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}

		///返回从数据库获取的结果
		return (dr);
	}

	public SqlDataReader GetProductByCategory(int nCategoryID)
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///定义保存从数据库获取的结果的DataReader
		SqlDataReader dr = null;

		///创建访问数据库的参数			
		SqlParameter[] paramList = {
			sqlHelper.CreateInParam("@CategoryID",SqlDbType.Int,4,nCategoryID)
		};

		try
		{
			///执行存储过程
			sqlHelper.RunProc("Pr_GetProductByCategory",paramList,out dr);
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}

		///返回从数据库获取的结果
		return (dr);
	}

	public SqlDataReader GetSingleProduct(int nProductID)
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///定义保存从数据库获取的结果的DataReader
		SqlDataReader dr = null;

		///创建访问数据库的参数			
		SqlParameter[] paramList = {
			sqlHelper.CreateInParam("@ProductID",SqlDbType.Int,4,nProductID)
		};

		try
		{
			///执行存储过程
			sqlHelper.RunProc("Pr_GetSingleProduct",paramList,out dr);
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}

		///返回从数据库获取的结果
		return (dr);
	}

	public DataTable SearchProduct(string sKeyword)
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///定义保存从数据库获取的结果的DataReader
		SqlDataReader dr = null;

		///创建访问数据库的参数			
		SqlParameter[] paramList = {
			sqlHelper.CreateInParam("@Keyword",SqlDbType.VarChar,200,sKeyword)
		};

		try
		{
			///执行存储过程
			sqlHelper.RunProc("Pr_SearchProduct",paramList,out dr);
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}

		///返回从数据库获取的结果
		return (SQLHelper.ConvertdrTodt(dr));
	}

	public DataTable AdvanceSearchProduct(string sName,string sSell,DateTime dMinDate,
		DateTime dMaxDate,Decimal dMinPrice,Decimal dMaxPrice)
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///定义保存从数据库获取的结果的DataReader
		SqlDataReader dr = null;

		///创建访问数据库的参数			
		SqlParameter[] paramList = {
			sqlHelper.CreateInParam("@Name",SqlDbType.VarChar,200,sName),
			sqlHelper.CreateInParam("@Sell",SqlDbType.VarChar,200,sSell),
			sqlHelper.CreateInParam("@MinDate",SqlDbType.DateTime,8,dMinDate),
			sqlHelper.CreateInParam("@MaxDate",SqlDbType.DateTime,8,dMaxDate),
			sqlHelper.CreateInParam("@MinPrice",SqlDbType.Money,8,dMinPrice),
			sqlHelper.CreateInParam("@MaxPrice",SqlDbType.Money,8,dMaxPrice)
		};

		try
		{
			///执行存储过程
			sqlHelper.RunProc("Pr_AdvanceSearchProduct",paramList,out dr);
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}

		///返回从数据库获取的结果
		return (SQLHelper.ConvertdrTodt(dr));
	}

	public int AddProduct(string sName,int nCategoryID,string sDesn,string sSell,
		DateTime dCreateDate,DateTime dSellInDate,string sUnit,int nQuantity,
		int nUpper,int nLower,Decimal dInPrice,Decimal dOutPrice,int nPictureID,
		string sRemark)
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///创建访问数据库的参数			
		SqlParameter[] paramList = {
			sqlHelper.CreateInParam("@Name",SqlDbType.VarChar,200,sName),
			sqlHelper.CreateInParam("@CategoryID",SqlDbType.Int,4,nCategoryID),
			sqlHelper.CreateInParam("@Desn",SqlDbType.Text,8000,sDesn),
			sqlHelper.CreateInParam("@Sell",SqlDbType.VarChar,200,sSell),
			sqlHelper.CreateInParam("@CreateDate",SqlDbType.DateTime,8,dCreateDate),
			sqlHelper.CreateInParam("@SellInDate",SqlDbType.DateTime,8,dSellInDate),
			sqlHelper.CreateInParam("@Unit",SqlDbType.VarChar,50,sUnit),
			sqlHelper.CreateInParam("@Quantity",SqlDbType.Int,4,nQuantity),
			sqlHelper.CreateInParam("@Upper",SqlDbType.Int,4,nUpper),
			sqlHelper.CreateInParam("@Lower",SqlDbType.Int,4,nLower),
			sqlHelper.CreateInParam("@InPrice",SqlDbType.Money,8,dInPrice),
			sqlHelper.CreateInParam("@OutPrice",SqlDbType.Money,8,dOutPrice),
			sqlHelper.CreateInParam("@PictureID",SqlDbType.Int,4,nPictureID),			
			sqlHelper.CreateInParam("@Remark",SqlDbType.Text,8000,sRemark)
		};

		try
		{
			///执行存储过程
			return (sqlHelper.RunProc("Pr_AddProduct",paramList));
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}
	}

	public void UpdateProduct(int nProductID,string sName,string sDesn,string sSell,
		DateTime dCreateDate,DateTime dSellInDate,string sUnit,int nQuantity,
		int nUpper,int nLower,Decimal dInPrice,Decimal dOutPrice,int nPictureID,
		string sRemark)
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///创建访问数据库的参数			
		SqlParameter[] paramList = {
			sqlHelper.CreateInParam("@ProductID",SqlDbType.Int,4,nProductID),
			sqlHelper.CreateInParam("@Name",SqlDbType.VarChar,200,sName),
			sqlHelper.CreateInParam("@Desn",SqlDbType.Text,8000,sDesn),
			sqlHelper.CreateInParam("@Sell",SqlDbType.VarChar,200,sSell),
			sqlHelper.CreateInParam("@CreateDate",SqlDbType.DateTime,8,dCreateDate),
			sqlHelper.CreateInParam("@SellInDate",SqlDbType.DateTime,8,dSellInDate),
			sqlHelper.CreateInParam("@Unit",SqlDbType.VarChar,50,sUnit),
			sqlHelper.CreateInParam("@Quantity",SqlDbType.Int,4,nQuantity),
			sqlHelper.CreateInParam("@Upper",SqlDbType.Int,4,nUpper),
			sqlHelper.CreateInParam("@Lower",SqlDbType.Int,4,nLower),
			sqlHelper.CreateInParam("@InPrice",SqlDbType.Money,8,dInPrice),
			sqlHelper.CreateInParam("@OutPrice",SqlDbType.Money,8,dOutPrice),
			sqlHelper.CreateInParam("@PictureID",SqlDbType.Int,4,nPictureID),			
			sqlHelper.CreateInParam("@Remark",SqlDbType.Text,8000,sRemark)
		};

		try
		{
			///执行存储过程
			sqlHelper.RunProc("Pr_UpdateProduct",paramList);
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}
	}
	
	public void DeleteProduct(int nProductID)
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///创建访问数据库的参数			
		SqlParameter[] paramList = {
			sqlHelper.CreateInParam("@ProductID",SqlDbType.Int,4,nProductID)
		};

		try
		{
			///执行存储过程
			sqlHelper.RunProc("Pr_DeleteProduct",paramList);
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}
	}
}
