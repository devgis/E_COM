﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public class News
{
	public SqlDataReader GetNewss()
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///定义保存从数据库获取的结果的DataReader
		SqlDataReader dr = null;

		try
		{
			///执行存储过程
			sqlHelper.RunProc("Pr_GetNewss",out dr);
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}

		///返回从数据库获取的结果
		return (dr);
	}

	public SqlDataReader GetSingleNews(int nNewsID)
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///定义保存从数据库获取的结果的DataReader
		SqlDataReader dr = null;

		///创建访问数据库的参数			
		SqlParameter[] paramList = {
			sqlHelper.CreateInParam("@NewsID",SqlDbType.Int,4,nNewsID)
		};

		try
		{
			///执行存储过程
			sqlHelper.RunProc("Pr_GetSingleNews",paramList,out dr);
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}

		///返回从数据库获取的结果
		return (dr);
	}

	public int AddNews(string sDesn,string sBody,int nUserID)
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///创建访问数据库的参数			
		SqlParameter[] paramList = {
			sqlHelper.CreateInParam("@Desn",SqlDbType.VarChar,200,sDesn),
			sqlHelper.CreateInParam("@Body",SqlDbType.Text,2147483647,sBody),
			sqlHelper.CreateInParam("@UserID",SqlDbType.Int,4,nUserID)
		};

		try
		{
			///执行存储过程
			return (sqlHelper.RunProc("Pr_AddNews",paramList));
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}
	}

	public void UpdateNews(int nNewsID,string sDesn,string sBody)
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///创建访问数据库的参数			
		SqlParameter[] paramList = {
			sqlHelper.CreateInParam("@NewsID",SqlDbType.Int,4,nNewsID),
			sqlHelper.CreateInParam("@Desn",SqlDbType.VarChar,200,sDesn),
			sqlHelper.CreateInParam("@Body",SqlDbType.Text,2147483647,sBody)
		};

		try
		{
			///执行存储过程
			sqlHelper.RunProc("Pr_UpdateNews",paramList);
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}
	}

	public void DeleteNews(int nNewsID)
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///创建访问数据库的参数			
		SqlParameter[] paramList = {
			sqlHelper.CreateInParam("@NewsID",SqlDbType.Int,4,nNewsID)
		};

		try
		{
			///执行存储过程
			sqlHelper.RunProc("Pr_DeleteNews",paramList);
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}
	}
}

public class Leaveword
{
	public SqlDataReader GetLeavewords()
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///定义保存从数据库获取的结果的DataReader
		SqlDataReader dr = null;

		try
		{
			///执行存储过程
			sqlHelper.RunProc("Pr_GetLeavewords",out dr);
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}

		///返回从数据库获取的结果
		return (dr);
	}

	public SqlDataReader GetSingleLeaveword(int nLeavewordID)
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///定义保存从数据库获取的结果的DataReader
		SqlDataReader dr = null;

		///创建访问数据库的参数			
		SqlParameter[] paramList = {
			sqlHelper.CreateInParam("@LeavewordID",SqlDbType.Int,4,nLeavewordID)
		};

		try
		{
			///执行存储过程
			sqlHelper.RunProc("Pr_GetSingleLeaveword",paramList,out dr);
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}

		///返回从数据库获取的结果
		return (dr);
	}

	public int AddLeaveword(string sDesn,string sBody,int nUserID)
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///创建访问数据库的参数			
		SqlParameter[] paramList = {
			sqlHelper.CreateInParam("@Desn",SqlDbType.VarChar,200,sDesn),
			sqlHelper.CreateInParam("@Body",SqlDbType.Text,2147483647,sBody),
			sqlHelper.CreateInParam("@UserID",SqlDbType.Int,4,nUserID)
		};

		try
		{
			///执行存储过程
			return (sqlHelper.RunProc("Pr_AddLeaveword",paramList));
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}
	}	

	public void DeleteLeaveword(int nLeavewordID)
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///创建访问数据库的参数			
		SqlParameter[] paramList = {
			sqlHelper.CreateInParam("@LeavewordID",SqlDbType.Int,4,nLeavewordID)
		};

		try
		{
			///执行存储过程
			sqlHelper.RunProc("Pr_DeleteLeaveword",paramList);
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}
	}
}

public class Notify
{
	public SqlDataReader GetNotify()
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///定义保存从数据库获取的结果的DataReader
		SqlDataReader dr = null;

		try
		{
			///执行存储过程
			sqlHelper.RunProc("Pr_GetNotify",out dr);
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}

		///返回从数据库获取的结果
		return (dr);
	}

	public void UpdateNotify(string sDesn,string sBody)
	{
		///定义类SQLHelper
		SQLHelper sqlHelper = new SQLHelper();

		///创建访问数据库的参数			
		SqlParameter[] paramList = {
			sqlHelper.CreateInParam("@Desn",SqlDbType.VarChar,200,sDesn),
			sqlHelper.CreateInParam("@Body",SqlDbType.Text,2147483647,sBody)
		};

		try
		{
			///执行存储过程
			sqlHelper.RunProc("Pr_UpdateNotify",paramList);
		}
		catch(Exception ex)
		{
			///抛出执行数据库异常
			SQLHelper.CreateErrorMsg(ex.Message);
			throw new Exception(ex.Message,ex);
		}
	}

}
