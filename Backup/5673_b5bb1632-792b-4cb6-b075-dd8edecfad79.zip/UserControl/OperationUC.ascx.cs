﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class UserControl_OperationUC : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
		if(Session["UserID"] != null && Session["RoleID"] != null)
		{
			OperationPanel.Controls.Clear();
			if(Session["RoleID"].ToString() == "1")
			{   ///加载管理员操作模块
				OperationPanel.Controls.Add(Page.LoadControl("~/UserControl/AdminOperationUC.ascx"));
			}
			if(Session["RoleID"].ToString() == "2")
			{   ///加载供销商操作模块
				OperationPanel.Controls.Add(Page.LoadControl("~/UserControl/CustomerOperationUC.ascx"));
			}
			if(Session["RoleID"].ToString() == "3")
			{   ///加载客户操作模块
				OperationPanel.Controls.Add(Page.LoadControl("~/UserControl/MyOperationUC.ascx"));
			}
		}
    }
	
	protected void LoginBtn_Click1(object sender,EventArgs e)
	{

		if(UserName.Text == null || UserName.Text == "" || UserName.Text.Length <= 0)
		{
			ShowMessage("用户名称为空，请输入用户名称！");
			return;
		}

		if(Password.Text == null || Password.Text == "" || Password.Text.Length <= 0)
		{
			ShowMessage("用户密码为空，请输入用户密码！");
			return;
		}

		String userId = "";
		string roleId = "";

		///定义类并获取用户的登陆信息            
		User user = new User();
		SqlDataReader recu = user.GetUserLogin(UserName.Text.Trim(),Password.Text.Trim());

		///判断用户是否合法
		if(recu.Read())
		{
			userId = recu["UserID"].ToString();
			roleId = recu["RoleID"].ToString();
		}
		recu.Close();

		///验证用户合法性，并跳转到系统平台
		if((userId != null) && (userId != ""))
		{
			Session["UserID"] = userId;
			Session["RoleID"] = roleId;
			Session["UserName"] = UserName.Text;
				
			//跳转到登录后的第一个页面
			Response.Redirect("~/Desktop/Product.aspx");
		}
		else
		{
			///显示错误信息
			ShowMessage("你输入的用户名称/密码有误，请重新输入！");
		}
	}

	private void ShowMessage(string sMsg)
	{
		///显示操作结果信息
		Response.Write("<script>window.alert('" + sMsg + "')</script>");
	}

	protected void SearchBtn_Click(object sender,EventArgs e)
	{
		if(Kewword.Text == null || Kewword.Text == "" || Kewword.Text.Length <= 0)
		{
			ShowMessage("搜索关键字为空，请输入关键字！");
			return;
		}
		Response.Write("<script>window.open('Search.aspx?Keyword=" + Server.HtmlEncode(Kewword.Text.Trim()) + "')</script>");
	}
}
