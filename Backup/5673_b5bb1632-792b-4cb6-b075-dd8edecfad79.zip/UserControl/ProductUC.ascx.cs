﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class UserControl_ProductUC : System.Web.UI.UserControl
{
	protected int nProductID;
	protected string sName;
	protected string sSell;
	protected DateTime dCreateDate;
	protected Decimal dPrice;
	protected string sDesn;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

	public void BindProductData(int nProductID)
	{	///获取数据
		Product product = new Product();
		SqlDataReader dr = product.GetSingleProduct(nProductID);

		this.nProductID = nProductID;
		///读取数据
		if(dr.Read())
		{
			///显示数据
			sName = dr["Name"].ToString();
			sDesn = dr["Desn"].ToString().Replace("\n","<br>");
			sSell = dr["Sell"].ToString();
			dCreateDate = DateTime.Parse(dr["CreateDate"].ToString());			
			dPrice = Decimal.Parse(dr["OutPrice"].ToString());			
		}
		dr.Close();          ///关闭数据源
	}

	protected void BuyBtn_Click(object sender,EventArgs e)
	{
		OrderItemInfo item = null;
		OrderInfo order = null;

		///添加到购物车中，购物车的数据使用Session保存
		if(Session[Session.SessionID + OrderForm.Cart] == null)
		{
			///当购物车没有任何信息时
			item = GetOrderItemInfo((Button)sender);

			if(item == null)
			{
				///显示错误信息					
				Response.Write("<script>window.alert('数据错误')</script>");
				return;
			}

			///创建订单信息               
			order = new OrderInfo();
			order.OrderItemList.Add(item);
			order.TotalMoney = item.ItemTotalMoney;
			order.TotalNumber = item.Number;

			///添加订单信息到Session中
			Session[Session.SessionID + OrderForm.Cart] = order;
		}
		else
		{
			///当购物车中已经存在商品信息时，从Session中获取以前的商品信息
			order = (OrderInfo)Session[Session.SessionID + OrderForm.Cart];
			item = GetOrderItemInfo((Button)sender);
			if(item == null)
			{
				///显示错误信息
				Response.Write("<script>window.alert('数据错误')</script>");
				return;
			}

			///判断是否已经添加该类型的商品
			int i = 0;
			for(i = 0; i < order.OrderItemList.Count; i++)
			{
				///如果添加了，则数量加一
				if(item.ProductID == ((OrderItemInfo)order.OrderItemList[i]).ProductID)
				{
					((OrderItemInfo)order.OrderItemList[i]).Number++;
					((OrderItemInfo)order.OrderItemList[i]).ItemTotalMoney += item.ItemTotalMoney;
					break;
				}
			}
			///否则添加新的商品
			if(i == order.OrderItemList.Count)
			{
				order.OrderItemList.Add(item);
			}
			///更新订单信息
			order.TotalNumber++;
			order.TotalMoney += item.ItemTotalMoney;
			Session[Session.SessionID + OrderForm.Cart] = order;
		}
		Response.Write("<script>window.alert('恭喜您，添加该商品到购物车成功！')</script>");
	}

	private OrderItemInfo GetOrderItemInfo(Button sender)
	{
		///当购物车没有任何信息时
		OrderItemInfo item = new OrderItemInfo();
		try
		{
			item.ProductID = Int32.Parse(sender.CommandArgument);
			item.Name = sender.CommandName;
			item.Number = 1;
			///获取商品价格
			item.Price = decimal.Parse(Price.Text);
			item.Date = DateTime.Now;
			///总价格
			item.ItemTotalMoney = item.Price;
		}
		catch
		{
			return null;
		}
		return (item);
	}
}
